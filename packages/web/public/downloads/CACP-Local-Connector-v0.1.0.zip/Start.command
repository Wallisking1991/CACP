#!/bin/bash
cd "$(dirname "$0")"

if ! command -v node &> /dev/null; then
    echo "============================================"
    echo "  Node.js is not installed."
    echo ""
    echo "  Please download Node.js 20+ from:"
    echo "  https://nodejs.org/"
    echo "============================================"
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

NODE_MAJOR=$(node -p 'process.version.match(/^v(\d+)/)[1]')
if [ "$NODE_MAJOR" -lt 20 ]; then
    echo "============================================"
    echo "  Node.js version is too old ($NODE_MAJOR)."
    echo "  Node.js 20+ is required."
    echo "  Please upgrade from https://nodejs.org/"
    echo "============================================"
    echo ""
    read -p "Press Enter to exit..."
    exit 1
fi

node index.cjs --detect-cli

echo "Starting CACP Local Connector..."
node index.cjs

echo ""
echo "CACP Local Connector has exited."
read -p "Press Enter to close..."
