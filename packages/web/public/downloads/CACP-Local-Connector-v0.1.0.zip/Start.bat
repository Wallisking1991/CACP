@echo off
setlocal

cd /d "%~dp0"

node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ============================================
    echo   Node.js is not installed.
    echo.
    echo   Please download Node.js 20+ from:
    echo   https://nodejs.org/
    echo ============================================
    echo.
    pause
    exit /b 1
)

for /f "tokens=1 delims=." %%a in ('node -p "process.version.match(/^v(\d+)/)[1]"') do set NODE_MAJOR=%%a
if %NODE_MAJOR% LSS 20 (
    echo ============================================
    echo   Node.js version is too old ^(%NODE_MAJOR%^).
    echo   Node.js 20+ is required.
    echo   Please upgrade from https://nodejs.org/
    echo ============================================
    pause
    exit /b 1
)

node index.cjs --detect-cli

echo.

echo Starting CACP Local Connector...
node index.cjs

echo.
echo CACP Local Connector has exited.
pause
